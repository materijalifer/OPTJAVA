package hr.fer.optjava.dz1.algoritmi.impl;

import hr.fer.optjava.dz1.algoritmi.GenetskiAlgoritam;

/**
 * nije implementirano
 * 
 * @author Eugen Rožić
 *
 */
public class SteadyStateBinImpl implements GenetskiAlgoritam {

	@Override
	public void start() {
		// TODO Auto-generated method stub
		
	}

}
